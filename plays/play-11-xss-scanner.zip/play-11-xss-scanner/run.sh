#!/usr/bin/env bash
echo "[INFO] Iniciando Play 11 — XSS Scanner"
# Comando de exemplo
sleep 1
echo "[SUCESSO] XSS Scanner concluído. Relatório gerado."
